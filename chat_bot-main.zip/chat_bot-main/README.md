# chat_bot with ApiOpenAI

#Preview
https://i.ibb.co/nrpGpSj/Screenshot-2023-0717-130622.jpg
